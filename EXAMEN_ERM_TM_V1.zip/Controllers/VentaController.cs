﻿using EXAMEN_ERM_TM.Business;
using EXAMEN_ERM_TM.Business.Venta;
using EXAMEN_ERM_TM.DI.IServices;
using EXAMEN_ERM_TM.Models;
using EXAMEN_ERM_TM.Models.DTO;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace EXAMEN_ERM_TM.Controllers
{
    public class VentaController : Controller
    {
        private readonly BdErmtmContext _context;
        private readonly IOperation<TblOpeVentum> _operationVenta;

        public VentaController(ILogger<HomeController> logger, BdErmtmContext context, IOperation<TblOpeVentum> operationVenta)
        {         
            this._context = context;
            this._operationVenta = operationVenta;

        }

        public IActionResult Index()
        {
            var result = BVenta.GetEventos(this._context, this._operationVenta);
            return View(result);
        }

        [HttpGet]
        public IActionResult VentaBoletosInfo(long? idEvento)
        {
            var result = BVenta.VentaBoletosInfo(this._context, this._operationVenta, idEvento);
            return View("VentaBoletosInfo",result);
        }



        [HttpGet]
        public JsonResult VentaBoletosInfoRefresh(long? idEvento)
        {
            var result = BVenta.VentaBoletosInfo(this._context, this._operationVenta, idEvento);
            return Json(result);
        }

        [HttpPost]
        public JsonResult GuardarVenta(DTOCompraBoleto requestData) {
            var result = BVenta.GuardarVenta(this._context, this._operationVenta, requestData);
            return Json(result);
        }


        [HttpGet]
        public JsonResult GetEventosRefresh()
        {
            var result = BVenta.GetEventos(this._context, this._operationVenta);
            return Json(result);
        }

        public IActionResult InformacionVentas() {         
            var result = BVenta.InformacionVentas(this._context, this._operationVenta);
            return View(result);

        }

    }
}

﻿using EXAMEN_ERM_TM.Business;
using EXAMEN_ERM_TM.Business.Evento;
using EXAMEN_ERM_TM.DI.IServices;
using EXAMEN_ERM_TM.Models;
using EXAMEN_ERM_TM.Models.DTO;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace EXAMEN_ERM_TM.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly BdErmtmContext _context;
        private readonly IOperation<TblOpeEvento> _operationEvento;

        public HomeController(ILogger<HomeController> logger, BdErmtmContext context, IOperation<TblOpeEvento> operationEvento)
        {
            _logger = logger;
            this._context = context;
            this._operationEvento = operationEvento;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetDefaultConfigurationSeat()
        {
            return Json(BEvento.GetDefaultConfigurationSeat(this._context, _operationEvento));

        }


        [HttpPost]
        public JsonResult GuardarEvento(DTOEventoRequest requestData)
        {
            return Json(BEvento.GuardarEvento(this._context, requestData, _operationEvento));

        }


        //public IActionResult Privacy()
        //{
        //    return View();
        //}

        //[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        //public IActionResult Error()
        //{
        //    return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        //}
    }
}
﻿(function ($) {

    var lstConfigurationSeat = [];
    $(document).ready(function () {
        
        GetConfigurationSeats();
        $('#btnAgregar').click(function () {

            debugger;
            let evento = {
                Nombre: $('#nombreEvento').val(),
                FechaEvento: $('#fechaEvento').val(),
            }
            let active = $('#chkActivo:checkbox[name=chkActivo]:checked').val()
            if (active == 'on') {
                evento.Active = true;
            } else {
                evento.Active = false;
            }

            var configurationCustom = {
                ConfiguracionDefault: lstConfigurationSeat
            }
            evento.ConfiguracionDefault = configurationCustom;
            let URL = $('#GuardarEvento').val();
            Request('POST', evento, $('#GuardarEvento').val()).
                then((response) => {
                    debugger;
                    ShowMessageInfo(response.item2);

                }).catch((error) => {
                    ShowMessageInfo(error);

                });



           

        });

    });


    function GetConfigurationSeats() {
        debugger;
        Request('GET', null, $("#GetDefaultConfigurationSeat").val()).
            then((response) => {
                debugger;
                let clasificacion = ""; 
                lstConfigurationSeat = response.configuracionDefault;
                $.each(response.configuracionDefault, function (index, value) {
                    debugger
                    if (clasificacion != value.clasificacion && index > 0) {

                        let asient = createSeat(value);
                        let containerClas = `<div id="${value.clasificacion}" class='row'>` +
                            asient +
                            `</div>`;

                        $('#ContenedorAsientosDfault').append(containerClas);


                    } else if (clasificacion == value.clasificacion && index > 0) {
                        let idAppened = '#ContenedorAsientosDfault ' + '#' + clasificacion;
                        let asient = createSeat(value);
                        $(idAppened).append(asient);
                    }

                    else if (index == 0) {
                        let asient = createSeat(value);
                        let containerClas = `<div id="${value.clasificacion}" class='row'>` +
                            asient+
                        `</div>`;

                        $('#ContenedorAsientosDfault').append(containerClas);
                    } 

                    

                    
                    clasificacion = value.clasificacion;
                });
            }).
            catch((error) => {
                ShowMessageInfo(error);
            });

    }


    function Request(verb, body, url) {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: url,
                type: verb,
                data: body,
                success: function (data) {
                    resolve(data)
                },
                error: function (error) {
                    reject(error)
                },
            })
        })
    }


    function ShowMessageInfo(message) {
        Swal.fire(message)

    }

    function createSeat(data) {
        debugger
        var row = "";
        if (data.disponible = true) {
            row = `<div id="${data.numeroLugar}" class='circleEnable'>` +
                `<label>${data.clasificacion + "-" + data.numeroLugar} </label>` +
                `</div>`;
        } else {
            row = `<div id="${data.numeroLugar}" class='circleDisable'>` +
                `<label>${data.clasificacion +"-"+ data.numeroLugar}</label>` +
                `</div>`;
        }         

        return row;


    }


})(jQuery);


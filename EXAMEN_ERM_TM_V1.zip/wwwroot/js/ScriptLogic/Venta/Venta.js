﻿(function ($) {

    var idEvento = 0;
    var lstConfigurationSeat = [];
   
    $(document).ready(function () {

        $("[id^= 'btnAdd_']").click(function () {
            debugger;
            $("#modalCompraBoleto").modal("show");
            idEvento = parseInt($(this).prop('name'));

        });

        $('#btnComprar').click(function () {
            debugger;
            let url = $('#VentaBoletosInfo').val() + '?idEvento=' + idEvento;            
            window.location.href = url;
            //Request('GET', null, url).
            //    then((response) => {
            //        debugger;
            //        let responseData = response;
            //    }).
            //    catch((error) => {
            //    });

        });
        $('#btnCancelar').click(function () {
            $("#modalCompraBoleto").modal("hide");
        });

    });




    function createSeat(data) {
        debugger
        var row = "";
        if (data.disponible = true) {
            row = `<div id="${data.numeroLugar}" class='circleEnable'>` +
                `<label>${data.clasificacion + "-" + data.numeroLugar} </label>` +
                `</div>`;
        } else {
            row = `<div id="${data.numeroLugar}" class='circleDisable'>` +
                `<label>${data.clasificacion + "-" + data.numeroLugar}</label>` +
                `</div>`;
        }

        return row;


    }

    function Request(verb, body, url) {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: url,
                type: verb,
                data: body,
                success: function (data) {
                    resolve(data)
                },
                error: function (error) {
                    reject(error)
                },
            })
        })
    }

    function ShowMessageInfo(message) {
        Swal.fire(message)

    }   


})(jQuery);


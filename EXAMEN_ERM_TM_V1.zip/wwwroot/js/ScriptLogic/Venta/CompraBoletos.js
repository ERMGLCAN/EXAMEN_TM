﻿(function ($) {

    var idEvento = 0;
    var lstConfigurationSeat = [];

    $(document).ready(function () {
        GetInfoEvento();

        $('#btnIncrement').click(function () {
            debugger
            let val = $('#spNumeroBoletos').text();
            let increment = parseInt(val) + 1;
            $('#spNumeroBoletos').text(increment);
        });

        $('#btnDecrement').click(function () {
            debugger
            //let val = $('#spNumeroBoletos span').text();
            let val = $("#spNumeroBoletos").text();

            let decrement = parseInt(val) - 1;
            if (decrement <= 0) {
                $('#spNumeroBoletos').text(0);
            } else {
                $('#spNumeroBoletos').text(decrement);
            }

        });

        $('#btnComprar').click(function () {
            if ($('#spNumeroBoletos').text() == '0') {
                return;
            }
            Swal.fire({
                title: 'Presiona el botón Ok para realizar la Compra',
                confirmButtonText: 'Ok',
            }).then((result) => {
                if (result.isConfirmed) {

                    let val = $('#spNumeroBoletos').text();
                    let cantidad = parseInt(val);
                    let compra = {
                        IdEvento: idEvento
                        , CantidadAsientos: cantidad
                    }

                    Request('POST', compra, $('#GuardarVenta').val()).
                        then((response) => {
                            if (response.isCorrect == true) {
                                $('#contentTicket').text(response.ticket);

                                $("#modalTiket").modal("show");
                            } else {
                                ShowMessageInfo(response.message);

                            }
                            $('#ContenedorAsientosDfault').empty();
                            GetInfoEvento();
                        }).
                        catch((error) => {
                            ShowMessageInfo(response.message);
                        });

                }




        })
            });

       

    });

    function GetInfoEvento() {
        debugger
        let idCard = $("[id^= 'card_']").prop('id');
        idEvento = idCard.replace('card_', '');
        let url = $('#VentaBoletosInfoRefresh').val() + '?idEvento=' + parseInt(idEvento);


        Request('GET', null, url)
            .then((response) => {
                debugger;
                let clasificacion = "";
                lstConfigurationSeat = response.configuracionDefault.configuracionDefault;
                $.each(response.configuracionDefault.configuracionDefault, function (index, value) {
                    debugger
                    if (clasificacion != value.clasificacion && index > 0) {

                        let asient = createSeat(value);
                        let containerClas = `<div id="${value.clasificacion}" class='row'>` +
                            asient +
                            `</div>`;

                        $('#ContenedorAsientosDfault').append(containerClas);


                    } else if (clasificacion == value.clasificacion && index > 0) {
                        let idAppened = '#ContenedorAsientosDfault ' + '#' + clasificacion;
                        let asient = createSeat(value);
                        $(idAppened).append(asient);
                    }

                    else if (index == 0) {
                        let asient = createSeat(value);
                        let containerClas = `<div id="${value.clasificacion}" class='row'>` +
                            asient +
                            `</div>`;

                        $('#ContenedorAsientosDfault').append(containerClas);
                    }




                    clasificacion = value.clasificacion;
                });

            })
            .catch((error) => {

            });
    }


    function createSeat(data) {
        debugger
        var row = "";
        if (data.disponible == true) {
            row = `<div id="${data.numeroLugar}" class='circleEnable'>` +
                `<label>${data.clasificacion + "-" + data.numeroLugar} </label>` +
                `</div>`;
        } else {
            row = `<div id="${data.numeroLugar}" class='circleDisable'>` +
                `<label>${data.clasificacion + "-" + data.numeroLugar}</label>` +
                `</div>`;
        }

        return row;


    }

    function Request(verb, body, url) {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: url,
                type: verb,
                data: body,
                success: function (data) {
                    resolve(data)
                },
                error: function (error) {
                    reject(error)
                },
            })
        })
    }

    function ShowMessageInfo(message) {
        Swal.fire(message)

    }


})(jQuery);


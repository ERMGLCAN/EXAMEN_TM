﻿using EXAMEN_ERM_TM.DI.IServices;
using EXAMEN_ERM_TM.DI.Services;
using EXAMEN_ERM_TM.Models;
using EXAMEN_ERM_TM.Models.DTO;
using Newtonsoft.Json;

namespace EXAMEN_ERM_TM.Business.Evento
{
    public static class BEvento
    {
        public static DTOConfigurationDefaultEvento? GetDefaultConfigurationSeat(BdErmtmContext context, IOperation<TblOpeEvento> operationEvento)
        {
            SOperation<TblOpeConfiguration> operationConf = new SOperation<TblOpeConfiguration>();
            var jsonDefaultConfiguration = operationConf.GetFirstOrDefault(context, c => c.Name == "DefaultConfiguration");
            if (jsonDefaultConfiguration is null || string.IsNullOrEmpty(jsonDefaultConfiguration?.Value))
            {
                throw new DataEntryException("No se encontró la configuración default");
            }
            var dtoConfiguration = JsonConvert.DeserializeObject<DTOConfigurationDefaultEvento>(jsonDefaultConfiguration.Value);
            return dtoConfiguration;
        }

        internal static Tuple<bool, string> GuardarEvento(BdErmtmContext context, DTOEventoRequest requestData, IOperation<TblOpeEvento> operationEvento)
        {
            if (requestData is null)
            {
                throw new DataEntryException("No se especificaron los datos del request");
            }
            if (!requestData.FechaEvento.HasValue || string.IsNullOrEmpty(requestData.Nombre) || requestData.ConfiguracionDefault is null)
            {
                throw new DataEntryException("No se especificaron los datos del request");
            }

            var evento = new TblOpeEvento()
            {
                Nombre = requestData.Nombre,
                FechaEvento = requestData.FechaEvento,
                Status = "Generado",
                CreationDate = DateTime.Now,
                CreationUser = "WOL",
                Active = true,
                
            };
            evento.ConfiguracionCustom = JsonConvert.SerializeObject(requestData.ConfiguracionDefault);
            var result = operationEvento.SaveEntity(evento, context);
            if (result.Id > 0)
            {
                return new Tuple<bool, string>(true, "Evento guardado");
            }
            else
            {
                return new Tuple<bool, string>(true, $"Error al guardar evento, por favor proporciona este código de error: {Guid.NewGuid().ToString("N")}");
            }

        }
    }
}

﻿namespace EXAMEN_ERM_TM.Business
{
    public enum ResponseCodeError : int
    {
        OK = 0,
        DataEntryError = 1,
        InternalError = 100
    }
}

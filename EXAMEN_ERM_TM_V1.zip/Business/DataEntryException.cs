﻿namespace EXAMEN_ERM_TM.Business
{
   
    public class DataEntryException : Exception
    {
        public DataEntryException(string message) : base(message)
        {
            ResponseCode = (int)ResponseCodeError.DataEntryError;
        }

        public DataEntryException(string message, int customResponseCode) : base(message)
        {
            ResponseCode = customResponseCode;
        }
        public DataEntryException(string message, Exception inner) : base(message, inner)
        {
            ResponseCode = (int)ResponseCodeError.DataEntryError;
        }

        public DataEntryException(string message, int customResponseCode, Exception inner) : base(message, inner)
        {
            ResponseCode = customResponseCode;
        }

        protected DataEntryException(System.Runtime.Serialization.SerializationInfo info, System.Runtime.Serialization.StreamingContext context) : base(info, context)
        {
            ResponseCode = (int)ResponseCodeError.DataEntryError;
        }
        public int? ResponseCode { get; private set; }
    }
}

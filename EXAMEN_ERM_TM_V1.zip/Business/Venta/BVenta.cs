﻿using EXAMEN_ERM_TM.DI.IServices;
using EXAMEN_ERM_TM.DI.Services;
using EXAMEN_ERM_TM.Models;
using EXAMEN_ERM_TM.Models.DTO;
using Newtonsoft.Json;
using System.Text;

namespace EXAMEN_ERM_TM.Business.Venta
{
    public class BVenta
    {
        internal static IEnumerable<DTOEventoResponse> GetEventos(BdErmtmContext context, IOperation<TblOpeVentum> operationVenta)
        {
            List<DTOEventoResponse> lstResult = new List<DTOEventoResponse>();
            SOperation<TblOpeEvento> operationEvento = new SOperation<TblOpeEvento>();
            var eventos = operationEvento.GetList(context, c=> c.Active == true && c.FechaEvento >= DateTime.Now);
            lstResult = (from ev in eventos
                         select new DTOEventoResponse()
                         {
                             Id = ev.Id,
                             Nombre = ev.Nombre,
                             FechaEvento = ev.FechaEvento,
                             Active = ev.Active,
                             ConfiguracionDefault = JsonConvert.DeserializeObject<DTOConfigurationDefaultEvento>(ev.ConfiguracionCustom),
                             PathImage = ev.PathImage

                         }).ToList();

            foreach (var ev in lstResult) {
                if (!ev.ConfiguracionDefault.ConfiguracionDefault.Any(c => c.Disponible = true))
                {
                    ev.Status = "Sin lugares disponibles";
                }
                else {
                    ev.Status = "Lugares disponibles";
                }
            }



            return lstResult;

        }

        internal static DTOCompraBoletoResponse GuardarVenta(BdErmtmContext context, IOperation<TblOpeVentum> operationVenta, DTOCompraBoleto requestData)
        {
            if (requestData is null) {
                throw new DataEntryException("No se ha especificado el request");
            }
            if (!requestData.CantidadAsientos.HasValue) {
                throw new DataEntryException("No se ha especificado la cantidad de boletos");
            }
            List<ConfiguracionAsientosDefault> asientosEncontrados = new List<ConfiguracionAsientosDefault>();

            SOperation<TblOpeEvento> operationEvento = new SOperation<TblOpeEvento>();
            var evento = operationEvento.GetFirstOrDefault(context, c=> c.Id == requestData.IdEvento && c.Active == true);
            var asientos = JsonConvert.DeserializeObject<DTOConfigurationDefaultEvento>(evento.ConfiguracionCustom);

            var findAll = asientos.ConfiguracionDefault.Where(c => c.Disponible == true).ToList();
            if (findAll.Count < requestData.CantidadAsientos) {
                return new DTOCompraBoletoResponse() { IsCorrect = false, Message = $"No se encontraron disponibles {requestData.CantidadAsientos} boletos, sólo existen {findAll.Count} boletos disponibles", lstBoletosEncontrados = asientosEncontrados };

            }


            for (int i = 0; i < requestData.CantidadAsientos; i++)
            {
                var exists = asientos.ConfiguracionDefault.FirstOrDefault(c => c.Disponible == true);
                if (exists != null) {
                    asientos.ConfiguracionDefault.FirstOrDefault(c => c.NumeroLugar == exists.NumeroLugar).Disponible = false;
                    asientosEncontrados.Add(exists);
                }
                
            }
            evento.ConfiguracionCustom = JsonConvert.SerializeObject(asientos);
            operationEvento.Update(evento, context);


           
           
            string ticket = GenerarVenta(context, asientosEncontrados, evento);



            return new DTOCompraBoletoResponse() { IsCorrect = true, Message = "Gracias por tu compra!", lstBoletosEncontrados = asientosEncontrados, ticket = ticket };            

        }

        internal static List<DTOInformacionVentaResponse> InformacionVentas(BdErmtmContext context, IOperation<TblOpeVentum> operationVenta)
        {
            List<DTOInformacionVentaResponse> response = new List<DTOInformacionVentaResponse>();
            SOperation<TblOpeEvento> operationEvento = new SOperation<TblOpeEvento>();
            SOperation<TblOpeVentaDetalle> operationVentaDetalle = new SOperation<TblOpeVentaDetalle>();

            var eventos = operationEvento.GetList(context, c=> c.Active == true);
            var ventas = operationVenta.GetAll(context);
            var ventasDetalle = operationVentaDetalle.GetAll(context);

            foreach (var evento in eventos)
            {
                var detalle = new DTOInformacionVentaResponse();
                detalle.NombreEvento = evento.Nombre;
                detalle.CodigoEvento = $"0000{evento.Id}";

                var ventaByEvento = ventas.Where(c => c.IdEvento == evento.Id).ToList();
                if (ventaByEvento.Count > 0)
                {

                    detalle.CantidadLugaresVendidos = ventaByEvento.Select(c => c.Cantidad).Sum();
                    detalle.TotalVendido = ventaByEvento.Select(c => c.Total).Sum();
                    detalle.NumeroVentas = ventaByEvento.Count();

                }
                else {
                    detalle.CantidadLugaresVendidos = 0;
                    detalle.TotalVendido = 0;
                    detalle.NumeroVentas = 0;
                }

                response.Add(detalle);
            }
            return response;

        }

        public static string GenerarVenta(BdErmtmContext context, List<ConfiguracionAsientosDefault> asientosEncontrados, TblOpeEvento evento) {

            SOperation<TblOpeVentum> operationVenta = new SOperation<TblOpeVentum>();
            TblOpeVentum venta = new TblOpeVentum() { 
             IdEvento = evento.Id
             , Cantidad = asientosEncontrados.Count()
             , Fecha = DateTime.Now
             , Total = (decimal)asientosEncontrados.Select(c=> c.Precio).Sum()
             , CreationUser = "WOL"
             , CreationDate = DateTime.Now,            
            };

            venta = operationVenta.SaveEntity(venta, context);

            SOperation<TblOpeVentaDetalle> operationVentaDetalle = new SOperation<TblOpeVentaDetalle>();
            foreach (var item in asientosEncontrados)
            {
                var detalleV = new TblOpeVentaDetalle() { 
                 IdVenta = venta.Id
                 , NumeroAsiento = item.NumeroLugar + "-" + item.Clasificacion
                 , Subtotal = (decimal)item.Precio                 
                 ,  CreationDate = DateTime.Now
                 , CreationUser = "WOL"                 
                };
                operationVentaDetalle.SaveEntity(detalleV, context);
            }
            return DataTicket(asientosEncontrados, evento);

        }

        public static string DataTicket(List<ConfiguracionAsientosDefault> asientosEncontrados,  TblOpeEvento evento) {
            StringBuilder detalleTcket = new StringBuilder();
            detalleTcket.Append($"**********EXAMEN ERM**********");
            detalleTcket.Append($"\n");
            detalleTcket.Append($"Referencia de Compra {Guid.NewGuid().ToString("N")}");
            detalleTcket.Append($"\n");
            detalleTcket.Append($"Evento: {evento.Nombre}");
            detalleTcket.Append($"\n");
            detalleTcket.Append($"Fecha Evento: {evento.FechaEvento}");
            detalleTcket.Append($"\n");

            foreach (var item in asientosEncontrados)
            {
                detalleTcket.Append($"Asiento : {item.NumeroLugar}-{item.Clasificacion} -> {item.Precio}");
                detalleTcket.Append($"\n");
            }
            detalleTcket.Append($"\n");
            detalleTcket.Append($"\n");
            detalleTcket.Append($"Total : {asientosEncontrados.Select(c=> c.Precio).Sum()}");
            detalleTcket.Append($"\n");

            detalleTcket.Append($"**********GRACIAS POR TU COMPRA!!!**********");
            return detalleTcket.ToString();
        }

        internal static DTOEventoResponse VentaBoletosInfo(BdErmtmContext context, IOperation<TblOpeVentum> operationVenta, long? idEvento)
        {
            SOperation<TblOpeEvento> operationEvento = new SOperation<TblOpeEvento>();
            var evento = operationEvento.GetFirstOrDefault(context, c=> c.Id == idEvento && c.Active == true);
            if (evento is null) {
                throw new DataEntryException("El evento ya no se encuentra activo.");
            }

            DTOEventoResponse response = new DTOEventoResponse() { 
             Id = evento.Id
             , Nombre = evento.Nombre
             , FechaEvento = evento.FechaEvento
             , PathImage = evento.PathImage
             , Status = evento.Status
             , Active = evento.Active                

            };

            response.ConfiguracionDefault = JsonConvert.DeserializeObject<DTOConfigurationDefaultEvento>(evento.ConfiguracionCustom);
            return response;

        }
    }
}

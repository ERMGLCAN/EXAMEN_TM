﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EXAMEN_ERM_TM.Models;

public partial class BdErmtmContext : DbContext
{
    public BdErmtmContext()
    {
    }

    public BdErmtmContext(DbContextOptions<BdErmtmContext> options)
        : base(options)
    {
    }

    public virtual DbSet<TblOpeConfiguration> TblOpeConfigurations { get; set; }

    public virtual DbSet<TblOpeEvento> TblOpeEventos { get; set; }

    public virtual DbSet<TblOpeVentaDetalle> TblOpeVentaDetalles { get; set; }

    public virtual DbSet<TblOpeVentum> TblOpeVenta { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=S0009704\\SQLEXPRESS;Initial Catalog=BD_ERMTM;Integrated Security=True;TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<TblOpeConfiguration>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Tbl_Ope___3214EC0736474882");

            entity.ToTable("Tbl_Ope_Configuration");

            entity.Property(e => e.CreationUser)
                .HasMaxLength(150)
                .IsUnicode(false);
            entity.Property(e => e.Descripcion)
                .HasMaxLength(300)
                .IsUnicode(false);
            entity.Property(e => e.ModificationUser)
                .HasMaxLength(150)
                .IsUnicode(false);
            entity.Property(e => e.Name)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.Value).IsUnicode(false);
        });

        modelBuilder.Entity<TblOpeEvento>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Tbl_Ope___3214EC079A075C0C");

            entity.ToTable("Tbl_Ope_Evento");

            entity.Property(e => e.ConfiguracionCustom).IsUnicode(false);
            entity.Property(e => e.CreationUser)
                .HasMaxLength(150)
                .IsUnicode(false);
            entity.Property(e => e.ModificationUser)
                .HasMaxLength(150)
                .IsUnicode(false);
            entity.Property(e => e.Nombre)
                .HasMaxLength(250)
                .IsUnicode(false);
            entity.Property(e => e.Status)
                .HasMaxLength(150)
                .IsUnicode(false);
            
        });

        modelBuilder.Entity<TblOpeVentaDetalle>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Tbl_Ope___3214EC07635BFA0F");

            entity.ToTable("Tbl_Ope_Venta_Detalle");

            entity.Property(e => e.CreationUser)
                .HasMaxLength(150)
                .IsUnicode(false);
            entity.Property(e => e.ModificationUser)
                .HasMaxLength(150)
                .IsUnicode(false);
            entity.Property(e => e.NumeroAsiento)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.Subtotal).HasColumnType("decimal(10, 4)");

            entity.HasOne(d => d.IdVentaNavigation).WithMany(p => p.TblOpeVentaDetalles)
                .HasForeignKey(d => d.IdVenta)
                .HasConstraintName("FK__Tbl_Ope_V__Creat__46E78A0C");
        });

        modelBuilder.Entity<TblOpeVentum>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Tbl_Ope___3214EC071996CE1C");

            entity.ToTable("Tbl_Ope_Venta");

            entity.Property(e => e.CreationUser)
                .HasMaxLength(150)
                .IsUnicode(false);
            entity.Property(e => e.Descripción)
                .HasMaxLength(250)
                .IsUnicode(false);
            entity.Property(e => e.ModificationUser)
                .HasMaxLength(150)
                .IsUnicode(false);
            entity.Property(e => e.Total).HasColumnType("decimal(10, 4)");

            entity.HasOne(d => d.IdEventoNavigation).WithMany(p => p.TblOpeVentum)
              .HasForeignKey(d => d.IdEvento)
              .HasConstraintName("FK__Tbl_Ope_V__IdEve__47DBAE45");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}

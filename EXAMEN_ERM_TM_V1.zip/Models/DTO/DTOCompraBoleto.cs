﻿namespace EXAMEN_ERM_TM.Models.DTO
{
    public class DTOCompraBoleto
    {
        public long? IdEvento {get; set; }
        public int? CantidadAsientos { get; set; }
        public decimal? Total { get; set; }
        public DateTime? FechaCompra { get; set; }

    }

    public class DTOCompraBoletoResponse {
        public bool? IsCorrect { get; set; }
        public string Message{ get; set; }
        public string ticket { get; set; }

        public List<ConfiguracionAsientosDefault> lstBoletosEncontrados { get; set; }

    }
}

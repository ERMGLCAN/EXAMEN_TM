﻿namespace EXAMEN_ERM_TM.Models.DTO
{
    public class DTOEventoRequest
    {
        public string? Nombre { get; set; }

        public DateTime? FechaEvento { get; set; }

        public DTOConfigurationDefaultEvento ConfiguracionDefault { get; set; }
        public bool? Active { get; set; }
    }


    public class DTOEventoResponse
    {
        public long? Id { get; set; }
        public string? Nombre { get; set; }

        public DateTime? FechaEvento { get; set; }

        public DTOConfigurationDefaultEvento? ConfiguracionDefault { get; set; }
        public bool? Active { get; set; }
        public string PathImage { get; set; }
        public string Status{ get; set; }
    }
}

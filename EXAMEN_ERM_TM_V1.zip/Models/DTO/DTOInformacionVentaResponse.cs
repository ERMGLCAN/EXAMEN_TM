﻿namespace EXAMEN_ERM_TM.Models.DTO
{
    public class DTOInformacionVentaResponse
    {
        public string CodigoEvento { get; set; }
        public string NombreEvento { get; set; }
        public int? NumeroVentas { get; set; }
        public int? CantidadLugaresVendidos { get; set; }
        public decimal? TotalVendido { get; set; }
    }
}

﻿namespace EXAMEN_ERM_TM.Models.DTO
{
    public class DTOConfigurationDefaultEvento
    {
        public List<ConfiguracionAsientosDefault> ConfiguracionDefault { get; set; }

    }

    public class ConfiguracionAsientosDefault {

        public string NumeroLugar { get; set; }
        public bool Disponible { get; set; }
        public bool Activo { get; set; }
        public double Precio { get; set; }
        public int Secuencia { get; set; }
        public string Clasificacion { get; set; }
    }
}

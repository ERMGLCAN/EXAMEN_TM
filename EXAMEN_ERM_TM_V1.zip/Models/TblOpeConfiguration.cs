﻿using System;
using System.Collections.Generic;

namespace EXAMEN_ERM_TM.Models;

public partial class TblOpeConfiguration
{
    public int Id { get; set; }

    public string? Name { get; set; }

    public string? Descripcion { get; set; }

    public string? Value { get; set; }

    public bool? Active { get; set; }

    public DateTime? ModificationDate { get; set; }

    public string? ModificationUser { get; set; }

    public DateTime? CreationDate { get; set; }

    public string? CreationUser { get; set; }
}

﻿using System;
using System.Collections.Generic;

namespace EXAMEN_ERM_TM.Models;

public partial class TblOpeEvento
{
    public long Id { get; set; }

    public string? Nombre { get; set; }

    public DateTime? FechaEvento { get; set; }

    public string? ConfiguracionCustom { get; set; }

    public string? Status { get; set; }

    public DateTime? ModificationDate { get; set; }

    public string? ModificationUser { get; set; }

    public DateTime? CreationDate { get; set; }

    public string? CreationUser { get; set; }
    public bool? Active { get; set; }
    public string? PathImage { get; set; }

    public virtual ICollection<TblOpeVentum> TblOpeVentum { get; } = new List<TblOpeVentum>();
}

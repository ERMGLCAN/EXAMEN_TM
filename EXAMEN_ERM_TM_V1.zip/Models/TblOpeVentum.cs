﻿using System;
using System.Collections.Generic;

namespace EXAMEN_ERM_TM.Models;

public partial class TblOpeVentum
{
    public long Id { get; set; }

    public DateTime? Fecha { get; set; }

    public int? Cantidad { get; set; }

    public decimal? Total { get; set; }

    public string? Descripción { get; set; }

    public DateTime? ModificationDate { get; set; }

    public string? ModificationUser { get; set; }

    public DateTime? CreationDate { get; set; }

    public string? CreationUser { get; set; }

    public virtual ICollection<TblOpeVentaDetalle> TblOpeVentaDetalles { get; } = new List<TblOpeVentaDetalle>();

    public long? IdEvento { get; set; }

    public virtual TblOpeEvento? IdEventoNavigation { get; set; }

}

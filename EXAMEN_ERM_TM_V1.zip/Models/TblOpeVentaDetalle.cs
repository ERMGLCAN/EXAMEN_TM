﻿using System;
using System.Collections.Generic;

namespace EXAMEN_ERM_TM.Models;

public partial class TblOpeVentaDetalle
{
    public long Id { get; set; }

    public long? IdVenta { get; set; }

    public string? NumeroAsiento { get; set; }

    public decimal? Subtotal { get; set; }

    public DateTime? ModificationDate { get; set; }

    public string? ModificationUser { get; set; }

    public DateTime? CreationDate { get; set; }

    public string? CreationUser { get; set; }

    public virtual TblOpeVentum? IdVentaNavigation { get; set; }
}

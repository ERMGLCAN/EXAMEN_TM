﻿using EXAMEN_ERM_TM.DI.IServices;
using EXAMEN_ERM_TM.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace EXAMEN_ERM_TM.DI.Services
{
    public class SOperation<TEntity> : IOperation<TEntity> where TEntity : class
    {
        private DbSet<TEntity>? entity = null;

        public bool Delete(long? id, BdErmtmContext _dbCotext)
        {
            entity = _dbCotext.Set<TEntity>();
            TEntity existing = entity.Find(id);
            if (existing != null)
            {
                _dbCotext.Remove(existing);
                _dbCotext.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }


        }

        public bool Delete(BdErmtmContext _dbCotext, Expression<Func<TEntity, bool>> predicate)
        {

            entity = _dbCotext.Set<TEntity>();
            IList<TEntity> result = entity.Where(predicate).ToList();
            foreach (var item in result)
            {
                _dbCotext.Remove(item);
                _dbCotext.SaveChanges();
            }
            return true;
        }

        public IEnumerable<TEntity> GetAll(BdErmtmContext _dbCotext)
        {
            entity = _dbCotext.Set<TEntity>();
            return entity.ToList(); ;
        }

        public TEntity GetById(long? id, BdErmtmContext _dbCotext)
        {
            entity = _dbCotext.Set<TEntity>();
            TEntity existing = _dbCotext.Find<TEntity>(id);
            return existing;
        }

        public TEntity GetFirstOrDefault(BdErmtmContext _dbCotext, Expression<Func<TEntity, bool>> predicate)
        {
            entity = _dbCotext.Set<TEntity>();
            return entity.Where(predicate).FirstOrDefault();
        }

        public IQueryable<TEntity> GetList(BdErmtmContext _dbCotext, Expression<Func<TEntity, bool>> predicate)
        {
            entity = _dbCotext.Set<TEntity>();
            return entity.Where(predicate);
        }


        public IQueryable<TEntity> GetListById(BdErmtmContext _dbCotext, Expression<Func<TEntity, bool>> predicate)
        {
            entity = _dbCotext.Set<TEntity>();
            return entity.Where(predicate);
        }

        public TEntity SaveEntity(TEntity entityIn, BdErmtmContext _dbCotext)
        {
            entity = _dbCotext.Set<TEntity>();
            //_dbCotext.Entry<TEntity>(entityIn).State = EntityState.Added;
            _dbCotext.Set<TEntity>().Add(entityIn);
            _dbCotext.SaveChanges();
            return entityIn;
        }

        public bool Update(TEntity entityIn, BdErmtmContext _dbCotext)
        {
            _dbCotext.Attach(entityIn);
            var response = _dbCotext.Entry(entityIn).State = EntityState.Modified;
            _dbCotext.SaveChanges();
            return true;
        }

        public bool Valdattion(object dto)
        {
            throw new NotImplementedException();
        }

        
    }
}


﻿using EXAMEN_ERM_TM.DI.IServices;
using EXAMEN_ERM_TM.DI.Services;
using EXAMEN_ERM_TM.Models;
using Microsoft.EntityFrameworkCore;

namespace EXAMEN_ERM_TM.DI
{
    public static class IOCServices
    {
        internal static void Services(IServiceCollection services, IConfiguration configuration)
        {


            services.AddTransient(typeof(IOperation<>), typeof(SOperation<>));
            services.AddDbContext<BdErmtmContext>(options =>
            {
                options.UseSqlServer(configuration.GetConnectionString("BdTMConectionString"));
            });


        }
    }
}

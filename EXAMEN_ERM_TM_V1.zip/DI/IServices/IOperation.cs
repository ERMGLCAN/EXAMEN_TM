﻿using EXAMEN_ERM_TM.Models;
using System.Linq.Expressions;

namespace EXAMEN_ERM_TM.DI.IServices
{
    public interface IOperation<T>
    {
        T SaveEntity(T entityIn, BdErmtmContext _dbCotext);
        T GetById(long? id, BdErmtmContext _dbCotext);

        bool Update(T entityIn, BdErmtmContext _dbCotext);

        bool Delete(long? id, BdErmtmContext _dbCotext);
        bool Delete(BdErmtmContext _dbCotext, Expression<Func<T, bool>> predicate);

        IQueryable<T> GetList(BdErmtmContext _dbCotext, Expression<Func<T, bool>> predicate);

        IEnumerable<T> GetAll(BdErmtmContext _dbCotext);

        bool Valdattion(Object dto);


        IQueryable<T> GetListById(BdErmtmContext _dbCotext, Expression<Func<T, bool>> predicate);
    }
}
